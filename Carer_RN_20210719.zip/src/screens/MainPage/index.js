import React, { memo, useState, useCallback } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { ScaledSheet } from 'react-native-size-matters';
import colors from '@ultis/colors';
import FONTS from '@ultis/fonts/index';
import { scaleHeight, scaleWidth } from '@ultis/size';
import TopicItem from '@screens/MainPage/components/TopicItem';
import SvgNurse from '@svgs/SvgNurse';
import SvgDoctor from '@svgs/MainPage/SvgDoctor';
import SvgHospital from '@svgs/MainPage/SvgHospital';
import SvgCalendar from '@svgs/MainPage/SvgCalendar';
import SvgPoint from '@svgs/MainPage/SvgPoint';
import ServiceItem from '@screens/MainPage/components/ServiceItem';
import ROUTES from '@ultis/routes';
import {
  getBottomSpace,
  getStatusBarHeight,
} from 'react-native-iphone-x-helper';

const TOPICDATA = [
  {
    color: colors.green,
    svg: <SvgNurse />,
    title: 'Stay Home\nCovid-19',
  },
  {
    color: colors.orange,
    svg: <SvgNurse />,
    title: 'Stay Home\nCovid-19',
  },
  {
    color: colors.classicBlue,
    svg: <SvgNurse />,
    title: 'Stay Home\nCovid-19',
  },
];

const MainPage = memo(({ navigation }) => {
  const [topicData, setTopicData] = useState(TOPICDATA);

  const onFindDoctor = useCallback(() => {
    navigation.navigate(ROUTES.FindDoctors);
  }, [navigation]);

  const onFindHospital = useCallback(() => {
    navigation.navigate(ROUTES.FindHospital);
  }, [navigation]);

  const onAppointment = useCallback(() => {
    navigation.navigate(ROUTES.AppointmentList);
  }, [navigation]);

  const onPriceServices = useCallback(() => {
    navigation.navigate(ROUTES.PricePlan);
  }, [navigation]);

  const renderTopicItem = () => {
    return topicData.map((item, index) => {
      const { color, svg, title } = item;
      return <TopicItem svg={svg} title={title} color={color} key={index} />;
    });
  };

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.contentStyle}
        showsVerticalScrollIndicator={false}>
        <Text style={styles.txtHi}>Hi! Gordon Aguilar,</Text>
        <Text style={styles.txtToday}>How about today?</Text>
        <ScrollView
          horizontal={true}
          bounces={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.contentContainerStyle}>
          {renderTopicItem()}
        </ScrollView>
        <View style={styles.flexWrap}>
          <ServiceItem
            onPress={onFindDoctor}
            svg={<SvgDoctor />}
            title={'Find Doctor'}
            content={'128 Doctors'}
          />
          <ServiceItem
            onPress={onFindHospital}
            svg={<SvgHospital />}
            title={'Find Hospital'}
            content={'96 Hospital'}
          />
          <ServiceItem
            onPress={onAppointment}
            svg={<SvgCalendar />}
            title={'Appointment'}
            content={'05 doctors'}
          />
          <ServiceItem
            onPress={onPriceServices}
            svg={<SvgPoint />}
            title={'Price Services'}
            content={'03 Plans'}
          />
        </View>
      </ScrollView>
    </View>
  );
});
export default MainPage;

const styles = ScaledSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.pageBackGround,
  },
  txtHi: {
    fontFamily: FONTS.HIND.SemiBold,
    fontWeight: '600',
    fontSize: scaleHeight(24),
    lineHeight: scaleHeight(38),
    color: colors.semiBlack,
    marginLeft: scaleWidth(24),
  },
  txtToday: {
    fontFamily: FONTS.HIND.Regular,
    fontWeight: '500',
    fontSize: scaleHeight(18),
    lineHeight: scaleHeight(30),
    color: colors.brown,
    marginLeft: scaleWidth(24),
    marginBottom: scaleHeight(20),
  },
  contentContainerStyle: {
    paddingLeft: scaleWidth(16),
    marginBottom: scaleHeight(24),
  },
  contentContainerFlatList: {
    paddingBottom: scaleHeight(80),
  },
  header: {
    backgroundColor: colors.classicBlue,
    borderBottomLeftRadius: scaleWidth(16),
    borderBottomRightRadius: scaleWidth(16),
    height: getStatusBarHeight() + scaleHeight(55),
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontFamily: FONTS.HIND.Regular,
    fontWeight: '500',
    fontSize: scaleHeight(17),
    color: colors.bluePrimary,
  },
  btnClose: {
    position: 'absolute',
    bottom: scaleHeight(11),
    left: scaleWidth(16),
  },
  btnOption: {
    position: 'absolute',
    bottom: scaleHeight(11),
    right: scaleWidth(16),
  },
  svgCarer: {
    position: 'absolute',
    bottom: scaleHeight(11),
  },
  flexWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  contentStyle: {
    paddingTop: scaleHeight(21),
    paddingBottom: getBottomSpace() + scaleHeight(90),
  },
});
