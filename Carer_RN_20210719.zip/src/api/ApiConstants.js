/* App config for apis
 */
const ApiConstants = {
  BASE_URL: 'http://wolverine-dev.com/',
  LOGIN: 'api/Users/login',
};

export default ApiConstants;
